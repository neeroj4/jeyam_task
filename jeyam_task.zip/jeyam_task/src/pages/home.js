import React from "react"
import Header from "../components/header"
import HomeSlider from "../components/homeSlider";
import '../styles/home.css'
import { ProductProvider } from "../components/productContext";
import Cart from "../components/cart";
import ProductList from "../components/productList";
import ContactForm from "../components/contactForm";
import Gallery from "../components/gallery";
const Home = () => {
    const [cart, setCart] = React.useState([]);

    const handleAddToCart = (product) => {
        setCart([...cart, product]);
    };
    return (
        <div  className="home-con">
            <Header />
            <HomeSlider />
            <ProductProvider>
                <div className="product-con">
                    <h3 className="product-h">Products</h3>
                    <ProductList />
                </div>
            </ProductProvider>
            <Gallery/>
            <div className="login-con">
                <h4 className="login-h">login form</h4>
                <ContactForm />
            </div>
        </div>

    )

}
export default Home;