// ContactForm.js
import React, { useState } from 'react';
import '../styles/contactform.css'
const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    subject: '',
    captcha: '',
  });

  const [errors, setErrors] = useState({
    name: '',
    email: '',
    mobile: '',
    subject: '',
    captcha: '',
  });

  const validateName = () => {
    // Validate name (only characters allowed)
    const regex = /^[a-zA-Z\s]*$/;
    if (!formData.name.match(regex)) {
      setErrors((prevErrors) => ({ ...prevErrors, name: 'Name should only contain characters' }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, name: '' }));
    }
  };

  const validateEmail = () => {
    // Validate email (only characters allowed)
    const regex = /^[a-zA-Z]*$/;
    if (!formData.email.match(regex)) {
      setErrors((prevErrors) => ({ ...prevErrors, email: 'Email should only contain characters' }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, email: '' }));
    }
  };

  const validateMobile = () => {
    // Validate mobile number (numeric, 10 digits, starts with 6,7,8,9)
    const regex = /^[6-9]\d{9}$/;
    if (!formData.mobile.match(regex)) {
      setErrors((prevErrors) => ({ ...prevErrors, mobile: 'Invalid mobile number' }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, mobile: '' }));
    }
  };

  const validateSubject = () => {
    // Validate subject (alphanumeric, character limit)
    const regex = /^[a-zA-Z0-9\s]*$/;
    if (!formData.subject.match(regex) || formData.subject.length > 50) {
      setErrors((prevErrors) => ({ ...prevErrors, subject: 'Invalid subject' }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, subject: '' }));
    }
  };

  const validateCaptcha = () => {
    // Validate captcha (not empty)
    if (!formData.captcha) {
      setErrors((prevErrors) => ({ ...prevErrors, captcha: 'Captcha is required' }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, captcha: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate all fields before submission
    validateName();
    validateEmail();
    validateMobile();
    validateSubject();
    validateCaptcha();

    // Check if there are no errors
    if (!Object.values(errors).some((error) => error !== '')) {
      // Perform form submission or send data to backend
      // For now, let's just log the form data
      console.log('Form submitted:', formData);
    }
  };

  const handleReset = () => {
    // Reset form data and errors
    setFormData({
      name: '',
      email: '',
      mobile: '',
      subject: '',
      captcha: '',
    });

    setErrors({
      name: '',
      email: '',
      mobile: '',
      subject: '',
      captcha: '',
    });
  };

  return (
    <div className='form-con'>
      <form onSubmit={handleSubmit} onReset={handleReset}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            onBlur={validateName}
          />
          {errors.name && <span>{errors.name}</span>}
        </div>

        <div>
          <label>Email Address:</label>
          <input
            type="text"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            onBlur={validateEmail}
          />
          {errors.email && <span>{errors.email}</span>}
        </div>

        <div>
          <label>Mobile number:</label>
          <input
            type="text"
            value={formData.mobile}
            onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
            onBlur={validateMobile}
          />
          {errors.mobile && <span>{errors.mobile}</span>}
        </div>

        <div>
          <label>Subject:</label>
          <input
            type="text"
            value={formData.subject}
            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
            onBlur={validateSubject}
          />
          {errors.subject && <span>{errors.subject}</span>}
        </div>

        <div>
          <label>Captcha:</label>
          <input
            type="text"
            value={formData.captcha}
            onChange={(e) => setFormData({ ...formData, captcha: e.target.value })}
            onBlur={validateCaptcha}
          />
          {errors.captcha && <span>{errors.captcha}</span>}
        </div>

        <div className='btn-row'>
          <button type="submit">Submit</button>
          <button type="reset">Reset</button>
        </div>
      </form>
    </div>
  );
};

export default ContactForm;
