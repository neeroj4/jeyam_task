import React, { useState } from 'react';
import { useProductContext } from './productContext';
import '../styles/product.css'
const Product = ({ product }) => {
  const { dispatch } = useProductContext();
  const [isHovered, setIsHovered] = useState(false);

  const handleAddToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  return (
    <div
      className="product-item"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <img className="product-image" src={product.imageUrl} alt={product.name} />
      {isHovered && (
        <div className="product-overlay">
          {product.videoUrl && (
            <video controls className="product-media">
              <source src={product.videoUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          )}
          <div className="product-details">
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <p>${product.price}</p>
            <button className='product-btn' onClick={handleAddToCart}>Add to Cart</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Product;
