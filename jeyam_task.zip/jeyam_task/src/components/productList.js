import React from 'react';
import Product from '../components/product';
import { useProductContext } from './productContext';
import '../styles/product.css'
const ProductList = () => {
  const { state } = useProductContext();

  return (
    <div className="product-list">
      {state.products.map((product) => (
        <Product key={product.id} product={product} />
      ))}
    </div>
  );
};

export default ProductList;
