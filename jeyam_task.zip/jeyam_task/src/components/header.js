import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/header.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartShopping, faBars,faXmark } from '@fortawesome/free-solid-svg-icons';
import Product from './product';
import Gallery from './gallery';

const Header = () => {
  const [isCartOpen, setCartOpen] = useState(false);
  const [isOpen, setOpen] = useState(false);

  const handleCartClick = () => {
    setCartOpen(!isCartOpen);
  };
  const sideClick=()=>{
    setOpen(!isOpen)
  }
  const closeClick=()=>{
    setOpen(false)
  }

  return (
    <header className="header">
      <div className="logo">
        <img className='logo-img' src='https://goayo.com/wp-content/uploads/2021/11/ayo-logo.svg' />
        <FontAwesomeIcon onClick={() => handleCartClick()} className='bar-icon' icon={faBars} />
      </div>
      <div className='con-2'>
      
          <nav className="nav-menu">
            <Link className='nav-menu-li' to="/">Home</Link>
            <Link className='nav-menu-li' to="/">Products</Link>
            <Link className='nav-menu-li' to="/">Gallery</Link>
            <Link className='nav-menu-li' to="/">Contact</Link>
            <button className='buy-btn'>Buy Ayo</button>
            <FontAwesomeIcon onClick={()=>sideClick()} className='head-icon' icon={faCartShopping} />
          </nav>
        
        {(isCartOpen) && (
          <nav className="nav-menu-2">
            <Link className='nav-menu-li' to="/">Home</Link>
            <Link className='nav-menu-li' to="/">Products</Link>
            <Link className='nav-menu-li' to="/">Gallery</Link>
            <Link className='nav-menu-li' to="/">Contact</Link>
            <button className='buy-btn'>Buy Ayo</button>
            <FontAwesomeIcon  className='head-icon' icon={faCartShopping} />
          </nav>
        )}
        {isOpen && <div className='sidenav-con'>
           <Gallery/>
           <FontAwesomeIcon onClick={closeClick} className='x-mark' icon={faXmark} />
        </div>}
        
      </div>

    </header>
  );
}

export default Header;
