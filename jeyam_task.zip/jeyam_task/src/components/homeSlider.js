// HomeSlider.js
import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../styles/slider.css';

const slidesData = [
  {
    imageUrl: 'https://dailyfresh.net.in/assets/images/banner1.jpg',
    title: 'Featured Product',
    description: 'Explore our latest and greatest product.',
    link: '/shop',
  },
  {
    imageUrl: 'https://dailyfresh.net.in/assets/images/banner.jpg',
    title: 'Special Offer',
    description: "Don't miss out on our exclusive offer. Limited time only!",
    link: '/specials',
  },
  // Add more slide data as needed
];

const HomeSlider = () => {
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 100,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    width: '100%',  // Set width to 100%
  };

  return (
    <div className="slider-wrapper" style={{ overflow: 'hidden' }}>
      <Slider {...sliderSettings}>
        {slidesData.map((slide, index) => (
          <div className='image-con' key={index}>
            <img className='slide-img' src={slide.imageUrl} alt={`Slide ${index + 1}`} />
            <div className="slide-content">
              <h2 className='slide-h'>{slide.title}</h2>
              <p className='slide-p'>{slide.description}</p>
              <button className='buy-btn'>Buy Ayo</button>
          
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default HomeSlider;
