import React, { useState } from 'react';
import '../styles/Gallery.css'; // Import your CSS file

const images = [
  'https://cdn.shopify.com/s/files/1/2303/2711/files/2_e822dae0-14df-4cb8-b145-ea4dc0966b34.jpg?v=1617059123',
  'https://media.istockphoto.com/id/1136422297/photo/face-cream-serum-lotion-moisturizer-and-sea-salt-among-bamboo-leaves.jpg?b=1&s=612x612&w=0&k=20&c=TAn7PO0GwGVQ6zeKyACdroy50orO90AlbxtnECt9Tho='
  ,
  'https://media.istockphoto.com/id/1300396642/photo/spa-cosmetics-products-branding-mockup-jar-of-moisturizer-cream-and-amber-glass-spray-bottle.jpg?s=612x612&w=0&k=20&c=Q_dbtb6PoS4GV8RnLWEQwPXtSeqaLEaDLO2piyAAFp8='
  // Add more image URLs as needed
];

const Gallery = () => {
  const [zoomedImage, setZoomedImage] = useState(null);

  const handleImageClick = (image) => {
    setZoomedImage(image);
  };

  const handleCloseZoom = () => {
    setZoomedImage(null);
  };

  return (
    <div className="gallery-container">
        <h2>Gallary</h2>
        <div className='gal-con'>
      {images.map((imageUrl, index) => (
        <div key={index} className="gallery-item">
          <img className='image-gal'
            src={imageUrl}
            alt={`Image ${index + 1}`}
            onClick={() => handleImageClick(imageUrl)}
          />
        </div>
      ))}

      {zoomedImage && (
        <div className="zoom-overlay" onClick={handleCloseZoom}>
          <div className="zoomed-image-container">
            <img src={zoomedImage} alt="Zoomed Image" />
          </div>
        </div>
      )}
      </div>
    </div>
  );
};

export default Gallery;
