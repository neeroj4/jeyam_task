import React, { createContext, useContext, useReducer } from 'react';

const ProductContext = createContext();

const initialState = {
  products: [
    { id: 1, name: 'Product 1', price: 20, description: 'Description 1', imageUrl: 'https://www.shutterstock.com/image-vector/ad-banner-natural-beauty-products-260nw-1780339220.jpg', videoUrl: 'https://www.youtube.com/watch?v=tZry4xuAfZs' },
    { id: 2, name: 'Product 2', price: 30, description: 'Description 2', imageUrl: 'https://www.shutterstock.com/image-vector/3d-illustration-green-tea-seed-260nw-1782648659.jpg', videoUrl: 'video2.mp4' },
    { id: 1, name: 'Product 1', price: 20, description: 'Description 1', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/65/Product_Photography.jpg', videoUrl: 'https://www.youtube.com/watch?v=tZry4xuAfZs' },
    { id: 2, name: 'Product 2', price: 30, description: 'Description 2', imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5_5XQ8l2rIaBF5vsANO0tDpwbr7RQD3tgpjyG0272uuaz2cWiabmE-q5V7JQmqbIp_GY&usqp=CAU', videoUrl: 'video2.mp4' },
    { id: 1, name: 'Product 1', price: 20, description: 'Description 1', imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPb5Wr4zPrMIwF7Lfp1FE6nZ2DB6brmUjenKVBK7c6dC1uWOctOdGOJSobzTUpNEePtmU&usqp=CAU', videoUrl: 'https://www.youtube.com/watch?v=tZry4xuAfZs' },
    { id: 2, name: 'Product 2', price: 30, description: 'Description 2', imageUrl: 'https://snapdirector.com/wp-content/uploads/2022/10/earth-bottle-photo-scaled.jpg', videoUrl: 'video2.mp4' },
    // Ad
    // Add more products as needed
  ],
  cart: [],
};

const productReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_TO_CART':
      return { ...state, cart: [...state.cart, action.payload] };
    default:
      return state;
  }
};

export const ProductProvider = ({ children }) => {
  const [state, dispatch] = useReducer(productReducer, initialState);

  return (
    <ProductContext.Provider value={{ state, dispatch }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProductContext = () => useContext(ProductContext);
